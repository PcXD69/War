# WarWatch

Live worldwide conflict news reader for Android (Kotlin + Jetpack Compose, cyber HUD theme).
Pulls RSS from Google News (5 conflict queries), Al Jazeera, BBC World and Sky News every 60 seconds,
tags each report by region and severity, and opens the full story in the browser.

Build locally: `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).
