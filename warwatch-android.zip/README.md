# WarWatch

Worldwide conflict monitor for Android (Kotlin + Jetpack Compose, cyber HUD theme).

- **NEWS** tab: live RSS from Google News (5 conflict queries), Al Jazeera, BBC World and Sky News, refreshed every 60 s.
  Region and severity tags, keyword filter, live ticker, tap to open the full story.
- **LIVE TV** tab: Al Jazeera English, DW News, France 24 English, Sky News and Euronews via their official
  YouTube live streams (embedded player, fullscreen supported, "Open in YouTube" fallback).
- **Day / Night** theme toggle (sun/moon morph, shockwave ring, twinkling stars at night). Choice is remembered.
- No gradients: flat solid colors only. Soft blur is applied only to the header, ticker and bottom bar
  (on theme switch and tab change; Android 12+).

Build locally: `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).
