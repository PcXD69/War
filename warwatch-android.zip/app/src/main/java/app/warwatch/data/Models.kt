package app.warwatch.data

internal fun rx(alternatives: String): Regex =
    Regex("\\b(?:$alternatives)", RegexOption.IGNORE_CASE)

enum class Severity(val label: String) {
    CRITICAL("CRITICAL"),
    ELEVATED("ELEVATED"),
    DIPLOMACY("DIPLOMACY"),
    INFO("INFO");

    companion object {
        private val critical = rx("killed|dead|death|strike|airstrike|missile|bomb|attack|shelling|shelled|drone|massacre|casualt|explosion|hostage|invasion")
        private val diplomacy = rx("ceasefire|truce|talks|peace|negotiat|deal|diplomat|summit")
        private val elevated = rx("war|troops|offensive|clashes|military|army|conflict|tension|warn|rebels|militia|frontline|navy|forces")

        fun detect(text: String): Severity = when {
            critical.containsMatchIn(text) -> CRITICAL
            diplomacy.containsMatchIn(text) -> DIPLOMACY
            elevated.containsMatchIn(text) -> ELEVATED
            else -> INFO
        }
    }
}

enum class Region(val label: String, private val keywords: List<String>) {
    ALL("ALL", emptyList()),
    MIDEAST(
        "MIDDLE EAST",
        listOf("gaza", "israel", "hamas", "hezbollah", "lebanon", "iran", "syria", "yemen", "houthi", "iraq", "west bank", "red sea", "beirut", "tehran")
    ),
    UKRAINE(
        "UKRAINE-RU",
        listOf("ukrain", "russia", "kyiv", "kiev", "moscow", "kharkiv", "donbas", "zelensky", "putin", "belarus", "crimea", "nato")
    ),
    AFRICA(
        "AFRICA",
        listOf("sudan", "congo", "drc", "sahel", "mali", "somalia", "ethiopia", "tigray", "nigeria", "burkina", "libya", "mozambique", "niger", "darfur")
    ),
    ASIA(
        "ASIA",
        listOf("myanmar", "taiwan", "korea", "kashmir", "india", "pakistan", "afghan", "china", "philippines", "taliban")
    ),
    GLOBAL("GLOBAL", emptyList());

    fun matches(text: String): Boolean =
        keywords.isNotEmpty() && rx(keywords.joinToString("|") { Regex.escape(it) }).containsMatchIn(text)

    companion object {
        private val searchable = listOf(MIDEAST, UKRAINE, AFRICA, ASIA)

        fun detect(text: String): Region =
            searchable.firstOrNull { it.matches(text) } ?: GLOBAL
    }
}

data class NewsItem(
    val id: String,
    val title: String,
    val link: String,
    val source: String,
    val publishedAt: Long,
    val summary: String,
    val region: Region,
    val severity: Severity,
)

data class LoadResult(val items: List<NewsItem>, val online: Int, val total: Int)
