package app.warwatch.data

data class TvChannel(
    val name: String,
    val channelId: String,
    val origin: String,
) {
    val liveUrl: String get() = "https://www.youtube.com/channel/$channelId/live"
}

object Channels {
    val all = listOf(
        TvChannel("AL JAZEERA ENGLISH", "UCNye-wNBqNL5ZzHSJj3l8Bg", "QATAR"),
        TvChannel("DW NEWS", "UCknLrEdhRCp1aegoMqRaCZg", "GERMANY"),
        TvChannel("FRANCE 24 ENGLISH", "UCQfwfsi5VrQ8yKZ-UWmAEFg", "FRANCE"),
        TvChannel("SKY NEWS", "UCoMdktPbSTixAyNGwb-UYkQ", "UNITED KINGDOM"),
        TvChannel("EURONEWS", "UCSrZ3UV4jOidv8ppoVuvW9Q", "EUROPE"),
    )
}
