package app.warwatch.data

import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

class NewsRepository {

    private data class Feed(val name: String, val url: String, val google: Boolean = false)

    private val feeds = listOf(
        Feed("GNEWS", gnews("war OR airstrike OR missile OR ceasefire OR offensive"), true),
        Feed("GNEWS", gnews("Gaza OR Israel OR Lebanon OR Iran OR Yemen OR Syria military"), true),
        Feed("GNEWS", gnews("Ukraine OR Russia frontline OR drone OR missile"), true),
        Feed("GNEWS", gnews("Sudan OR Congo OR Sahel OR Somalia conflict"), true),
        Feed("GNEWS", gnews("Myanmar OR Taiwan OR Kashmir OR Korea military"), true),
        Feed("AL JAZEERA", "https://www.aljazeera.com/xml/rss/all.xml"),
        Feed("BBC", "https://feeds.bbci.co.uk/news/world/rss.xml"),
        Feed("SKY NEWS", "https://feeds.skynews.com/feeds/rss/world.xml"),
    )

    val totalFeeds: Int get() = feeds.size

    suspend fun load(): LoadResult = coroutineScope {
        val now = System.currentTimeMillis()
        val results = feeds
            .map { feed -> async(Dispatchers.IO) { runCatching { fetch(feed, now) }.getOrNull() } }
            .awaitAll()

        val online = results.count { it != null }
        val items = results.filterNotNull().flatten()
            .distinctBy { it.id }
            .sortedByDescending { it.publishedAt }
            .take(160)
        LoadResult(items, online, feeds.size)
    }

    private fun fetch(feed: Feed, now: Long): List<NewsItem> {
        val conn = URL(feed.url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) WarWatch/1.0")
            conn.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            val raw = conn.inputStream.use { RssParser.parse(it) }
            return raw.mapNotNull { toItem(it, feed, now) }
        } finally {
            conn.disconnect()
        }
    }

    private fun toItem(raw: RawItem, feed: Feed, now: Long): NewsItem? {
        var title = clean(raw.title)
        if (title.isBlank() || raw.link.isBlank()) return null

        val source = if (feed.google) raw.source.ifBlank { "NEWS" } else feed.name
        if (feed.google && raw.source.isNotBlank()) title = title.removeSuffix(" - ${raw.source}")

        val summary = if (feed.google) "" else clean(raw.description).take(200)
        val text = "$title $summary"
        if (!feed.google && !RELEVANT.containsMatchIn(text)) return null

        val published = minOf(parseDate(raw.date) ?: now, now)
        if (now - published > MAX_AGE_MS) return null

        val key = title.lowercase().filter { it.isLetterOrDigit() }.take(48)
        if (key.isEmpty()) return null

        return NewsItem(
            id = key,
            title = title,
            link = raw.link,
            source = source,
            publishedAt = published,
            summary = summary,
            region = Region.detect(text),
            severity = Severity.detect(text),
        )
    }

    private fun clean(html: String): String =
        Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString()
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun parseDate(value: String): Long? {
        if (value.isBlank()) return null
        for (pattern in DATE_PATTERNS) {
            try {
                val parsed = SimpleDateFormat(pattern, Locale.US).parse(value)
                if (parsed != null) return parsed.time
            } catch (_: Exception) {
            }
        }
        return null
    }

    companion object {
        private const val MAX_AGE_MS = 72L * 60 * 60 * 1000

        private val DATE_PATTERNS = listOf(
            "EEE, dd MMM yyyy HH:mm:ss zzz",
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
        )

        private val RELEVANT = rx(
            "war|attack|strike|airstrike|missile|drone|bomb|troops|military|army|ceasefire|truce|" +
                "killed|shelling|offensive|frontline|militia|rebels|insurgen|hostage|invasion|conflict|navy|gunmen|clashes"
        )

        private fun gnews(query: String): String =
            "https://news.google.com/rss/search?q=" +
                URLEncoder.encode("$query when:2d", "UTF-8") +
                "&hl=en-US&gl=US&ceid=US:en"
    }
}
