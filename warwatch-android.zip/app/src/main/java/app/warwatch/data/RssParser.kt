package app.warwatch.data

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream

data class RawItem(
    val title: String,
    val link: String,
    val date: String,
    val description: String,
    val source: String,
)

object RssParser {

    fun parse(stream: InputStream): List<RawItem> {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(stream, null)

        val out = ArrayList<RawItem>()
        var inItem = false
        var title = ""
        var link = ""
        var date = ""
        var desc = ""
        var source = ""

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                val name = parser.name.lowercase()
                if (name == "item" || name == "entry") {
                    inItem = true
                    title = ""; link = ""; date = ""; desc = ""; source = ""
                } else if (inItem) {
                    when (name) {
                        "title" -> title = parser.nextText()
                        "link" -> {
                            val href: String? = parser.getAttributeValue(null, "href")
                            val text = parser.nextText()
                            if (link.isBlank()) link = if (!href.isNullOrBlank()) href else text
                        }
                        "pubdate", "published", "updated", "dc:date" ->
                            if (date.isBlank()) date = parser.nextText()
                        "description", "summary" -> desc = parser.nextText()
                        "source" ->
                            if (parser.getAttributeValue(null, "url") != null) source = parser.nextText()
                    }
                }
            } else if (event == XmlPullParser.END_TAG) {
                val name = parser.name.lowercase()
                if ((name == "item" || name == "entry") && inItem) {
                    out.add(RawItem(title, link.trim(), date.trim(), desc, source.trim()))
                    inItem = false
                }
            }
            event = parser.next()
        }
        return out
    }
}
