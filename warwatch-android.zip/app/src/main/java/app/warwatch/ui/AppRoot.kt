package app.warwatch.ui

import android.content.Context
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.warwatch.NewsViewModel
import app.warwatch.data.Channels
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun AppRoot(vm: NewsViewModel = viewModel()) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("warwatch", Context.MODE_PRIVATE) }

    var day by rememberSaveable { mutableStateOf(prefs.getBoolean("day", false)) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var channelIndex by rememberSaveable { mutableStateOf(0) }

    val state by vm.state.collectAsStateWithLifecycle()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refresh()
                delay(60_000)
            }
        }
    }

    // 0 = night, 1 = day. One animated value drives colors, ambient layer, blur pulse and toggle icon.
    val t by animateFloatAsState(
        targetValue = if (day) 1f else 0f,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "theme",
    )
    val ring = remember { Animatable(0f) }
    var toggleCenter by remember { mutableStateOf(Offset.Zero) }
    val scope = rememberCoroutineScope()

    val synced = remember(state.lastSync) {
        if (state.lastSync == 0L) "--:--:--"
        else SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(state.lastSync))
    }

    // Tab switch: chrome (header / ticker / bottom bar) briefly blurs and snaps back into focus.
    val tabBlur = remember { Animatable(0f) }
    LaunchedEffect(tab) {
        tabBlur.snapTo(1f)
        tabBlur.animateTo(0f, tween(450, easing = LinearOutSlowInEasing))
    }

    WarWatchTheme(t) {
        // Soft blur is applied ONLY to the chrome: during the theme switch and on tab change (Android 12+; no-op below).
        val chromeBlur = (max(sin(PI * t).toFloat() * 6f, tabBlur.value * 5f)).dp
        val ringColor = if (day) Cyber.Amber else Cyber.Cyan

        Box(Modifier.fillMaxSize().background(Cyber.Void)) {
            StarField(t)

            Column(Modifier.fillMaxSize()) {
                Header(
                    subtitle = if (tab == 0) {
                        "LINK ${state.online}/${state.total}   FEED ${state.items.size}   SYNC $synced"
                    } else {
                        "CHANNELS ${Channels.all.size}   SIGNAL LIVE   24/7"
                    },
                    showSync = tab == 0,
                    loading = state.loading,
                    t = t,
                    blur = chromeBlur,
                    onSync = vm::refresh,
                    onToggle = {
                        day = !day
                        prefs.edit().putBoolean("day", day).apply()
                        scope.launch {
                            ring.snapTo(0f)
                            ring.animateTo(1f, tween(900, easing = LinearOutSlowInEasing))
                        }
                    },
                    onToggleCenter = { toggleCenter = it },
                )

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    Crossfade(targetState = tab, animationSpec = tween(350), label = "tab") { page ->
                        if (page == 0) {
                            NewsScreen(state, vm::setQuery, vm::setRegion, chromeBlur)
                        } else {
                            LiveTvScreen(channelIndex) { channelIndex = it }
                        }
                    }
                }

                BottomBar(tab, chromeBlur) { tab = it }
            }

            Scanlines(t)
            RingOverlay(ring.value, toggleCenter, ringColor)
        }
    }
}

@Composable
private fun Header(
    subtitle: String,
    showSync: Boolean,
    loading: Boolean,
    t: Float,
    blur: Dp,
    onSync: () -> Unit,
    onToggle: () -> Unit,
    onToggleCenter: (Offset) -> Unit,
) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val alpha by pulse.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "alpha",
    )
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (blur > 0.dp) Modifier.blur(blur) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).background(Cyber.Magenta.copy(alpha = alpha), CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = "WARWATCH",
                color = Cyber.Cyan,
                fontFamily = Mono,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 22.sp,
                letterSpacing = 3.sp,
                style = TextStyle(shadow = Shadow(Cyber.Cyan, Offset.Zero, 18f * Cyber.glow)),
            )
            Text(
                text = subtitle,
                color = Cyber.Dim,
                fontFamily = Mono,
                fontSize = 10.sp,
                maxLines = 2,
            )
        }
        if (showSync) {
            val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
            Box(
                Modifier
                    .clip(shape)
                    .border(1.dp, Cyber.Cyan, shape)
                    .clickable(onClick = onSync)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                Text(
                    text = if (loading) "SYNCING" else "SYNC",
                    color = Cyber.Cyan,
                    fontFamily = Mono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                )
            }
            Spacer(Modifier.width(10.dp))
        }
        ThemeToggle(t, onToggle, onToggleCenter)
    }
}

/** Moon <-> sun morph: crescent cut closes into a full disc while rays grow in and rotate. */
@Composable
private fun ThemeToggle(t: Float, onClick: () -> Unit, onCenter: (Offset) -> Unit) {
    val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
    val accent = colorLerp(Cyber.Cyan, Cyber.Amber, t)
    Box(
        Modifier
            .size(40.dp)
            .clip(shape)
            .border(1.dp, accent, shape)
            .onGloballyPositioned { c ->
                onCenter(c.positionInRoot() + Offset(c.size.width / 2f, c.size.height / 2f))
            }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier
                .size(28.dp)
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        ) {
            val c = center
            val r = size.minDimension * (0.20f + 0.04f * t)
            drawCircle(accent, radius = r, center = c)

            val cut = 1f - t
            if (cut > 0.01f) {
                drawCircle(
                    color = Color.Black,
                    radius = r * 0.85f * cut,
                    center = c + Offset(r * 0.70f * cut, -r * 0.55f * cut),
                    blendMode = BlendMode.Clear,
                )
            }
            if (t > 0.01f) {
                for (i in 0 until 8) {
                    val angle = (i * 45f + 90f * t) * (PI.toFloat() / 180f)
                    val inner = r * 1.5f
                    val outer = r * (1.5f + 0.45f * t)
                    drawLine(
                        color = accent.copy(alpha = t),
                        start = c + Offset(cos(angle) * inner, sin(angle) * inner),
                        end = c + Offset(cos(angle) * outer, sin(angle) * outer),
                        strokeWidth = 1.6.dp.toPx(),
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomBar(tab: Int, blur: Dp, onTab: (Int) -> Unit) {
    val line = Cyber.Line
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (blur > 0.dp) Modifier.blur(blur) else Modifier)
            .background(Cyber.Panel)
            .drawBehind {
                drawLine(line, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 1.dp.toPx())
            }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TabButton("NEWS", live = false, selected = tab == 0, modifier = Modifier.weight(1f)) { onTab(0) }
        TabButton("LIVE TV", live = true, selected = tab == 1, modifier = Modifier.weight(1f)) { onTab(1) }
    }
}

@Composable
private fun TabButton(
    label: String,
    live: Boolean,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val p by animateFloatAsState(if (selected) 1f else 0f, tween(300), label = "tabSelect")
    val pulse = rememberInfiniteTransition(label = "liveDot")
    val dot by pulse.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "dot",
    )
    val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
    Row(
        modifier
            .clip(shape)
            .background(Cyber.Cyan.copy(alpha = 0.14f * p))
            .border(1.dp, colorLerp(Cyber.Line, Cyber.Cyan, p), shape)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (live) {
            Box(Modifier.size(8.dp).background(Cyber.Magenta.copy(alpha = dot), CircleShape))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = label,
            color = colorLerp(Cyber.Dim, Cyber.Cyan, p),
            fontFamily = Mono,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            letterSpacing = 2.sp,
            style = TextStyle(shadow = Shadow(Cyber.Cyan.copy(alpha = p), Offset.Zero, 14f * Cyber.glow * p)),
        )
    }
}

/** Gradient-free night sky: twinkling stars that fade out when the day theme comes in. */
@Composable
private fun StarField(t: Float) {
    if (t >= 0.99f) return
    val inf = rememberInfiniteTransition(label = "stars")
    val phase by inf.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing)),
        label = "phase",
    )
    val stars = remember {
        val r = Random(7)
        List(42) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) }
    }
    Canvas(Modifier.fillMaxSize()) {
        val night = 1f - t
        stars.forEachIndexed { i, s ->
            val twinkle = 0.35f + 0.65f * abs(sin(phase * (1 + i % 3) + i))
            drawCircle(
                color = Color.White.copy(alpha = 0.55f * twinkle * night),
                radius = (0.6f + 1.2f * s.third).dp.toPx(),
                center = Offset(s.first * size.width, s.second * size.height),
            )
        }
    }
}

@Composable
private fun Scanlines(t: Float) {
    val alpha = 0.12f * (1f - 0.75f * t)
    Canvas(Modifier.fillMaxSize()) {
        val step = 4.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = Color.Black.copy(alpha = alpha),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1f,
            )
            y += step
        }
    }
}

/** Expanding shockwave that starts at the toggle button every time the theme flips. */
@Composable
private fun RingOverlay(progress: Float, origin: Offset, color: Color) {
    if (progress <= 0f || progress >= 1f) return
    Canvas(Modifier.fillMaxSize()) {
        val maxR = hypot(max(origin.x, size.width - origin.x), max(origin.y, size.height - origin.y))
        val r = maxR * progress
        val fade = 1f - progress
        drawCircle(color.copy(alpha = 0.10f * fade), radius = r, center = origin)
        drawCircle(color.copy(alpha = 0.18f * fade), radius = r, center = origin, style = Stroke(width = 36f * fade + 4f))
        drawCircle(color.copy(alpha = 0.95f * fade), radius = r, center = origin, style = Stroke(width = 4f))
    }
}
