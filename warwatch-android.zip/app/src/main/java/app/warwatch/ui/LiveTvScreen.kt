package app.warwatch.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.warwatch.data.Channels
import app.warwatch.data.TvChannel

@Composable
fun LiveTvScreen(selected: Int, onSelect: (Int) -> Unit) {
    val context = LocalContext.current
    val index = selected.coerceIn(0, Channels.all.lastIndex)
    val channel = Channels.all[index]

    var fullscreen by remember { mutableStateOf(false) }
    val chrome = remember { FullscreenChrome(context.findActivity()) { fullscreen = it } }
    var webView by remember { mutableStateOf<WebView?>(null) }

    BackHandler(enabled = fullscreen) { chrome.exit(notify = true) }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { webView?.onPause() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { webView?.onResume() }
    DisposableEffect(Unit) { onDispose { chrome.exit(notify = true) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Player(
            channel = channel,
            chrome = chrome,
            onWebView = { if (webView !== it) webView = it },
        )
        NowPlaying(channel) {
            runCatching {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(channel.liveUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        Column(
            Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Channels.all.forEachIndexed { i, ch ->
                ChannelCard(i + 1, ch, selected = i == index) { onSelect(i) }
            }
        }

        Text(
            text = "Streams are the broadcasters' official YouTube live feeds. If one does not play in your region or is not embeddable, use OPEN IN YOUTUBE.",
            color = Cyber.Dim,
            fontFamily = Mono,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun Player(
    channel: TvChannel,
    chrome: FullscreenChrome,
    onWebView: (WebView) -> Unit,
) {
    val cyan = Cyber.Cyan
    Box(
        Modifier
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .background(Color.Black)
            .border(1.dp, Cyber.Line),
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    setBackgroundColor(android.graphics.Color.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            if (!request.isForMainFrame) return false
                            runCatching {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                            return true
                        }
                    }
                    webChromeClient = chrome
                }
            },
            update = { view ->
                onWebView(view)
                if (view.tag != channel.channelId) {
                    view.tag = channel.channelId
                    view.loadDataWithBaseURL("https://warwatch.app", embedHtml(channel), "text/html", "utf-8", null)
                }
            },
            onRelease = { view ->
                view.stopLoading()
                view.destroy()
            },
        )
        HudCorners(cyan)
    }
}

private fun embedHtml(channel: TvChannel): String = """
<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
html,body{margin:0;height:100%;background:#000;overflow:hidden}
iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0}
</style></head><body>
<iframe src="https://www.youtube.com/embed/live_stream?channel=${channel.channelId}&amp;autoplay=1&amp;playsinline=1&amp;rel=0&amp;modestbranding=1"
 allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>
</body></html>
""".trimIndent()

@Composable
private fun HudCorners(color: Color) {
    Canvas(Modifier.fillMaxSize()) {
        val len = 18.dp.toPx()
        val w = 2.dp.toPx()
        val e = w / 2f
        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            drawLine(color, Offset(x, y), Offset(x + dx * len, y), w)
            drawLine(color, Offset(x, y), Offset(x, y + dy * len), w)
        }
        corner(e, e, 1f, 1f)
        corner(size.width - e, e, -1f, 1f)
        corner(e, size.height - e, 1f, -1f)
        corner(size.width - e, size.height - e, -1f, -1f)
    }
}

@Composable
private fun NowPlaying(channel: TvChannel, onOpenYoutube: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "onair")
    val dot by pulse.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "onairDot",
    )
    val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(9.dp).background(Cyber.Magenta.copy(alpha = dot), CircleShape))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("ON AIR", color = Cyber.Magenta, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            Text(
                channel.name,
                color = Cyber.Text,
                fontFamily = Mono,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
            )
        }
        Box(
            Modifier
                .clip(shape)
                .border(1.dp, Cyber.Cyan, shape)
                .clickable(onClick = onOpenYoutube)
                .padding(horizontal = 12.dp, vertical = 9.dp),
        ) {
            Text("OPEN IN YOUTUBE", color = Cyber.Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun ChannelCard(number: Int, channel: TvChannel, selected: Boolean, onClick: () -> Unit) {
    val shape = CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp)
    val accent = if (selected) Cyber.Cyan else Cyber.Line
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) Cyber.Cyan.copy(alpha = 0.12f) else Cyber.Panel)
            .border(1.dp, accent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = number.toString().padStart(2, '0'),
            color = if (selected) Cyber.Cyan else Cyber.Dim,
            fontFamily = Mono,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                channel.name,
                color = Cyber.Text,
                fontFamily = Mono,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
            )
            Text(channel.origin, color = Cyber.Dim, fontFamily = Mono, fontSize = 10.sp)
        }
        Text(
            text = if (selected) "PLAYING" else "LIVE",
            color = if (selected) Cyber.Cyan else Cyber.Magenta,
            fontFamily = Mono,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
        )
    }
}

/** Handles the player's fullscreen button: shows the video full screen in landscape and restores afterwards. */
private class FullscreenChrome(
    private val activity: Activity?,
    private val onChange: (Boolean) -> Unit,
) : WebChromeClient() {
    private var customView: View? = null
    private var viewCallback: WebChromeClient.CustomViewCallback? = null

    override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
        val act = activity
        if (act == null || customView != null) {
            callback.onCustomViewHidden()
            return
        }
        customView = view
        viewCallback = callback
        (act.window.decorView as FrameLayout).addView(
            view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        WindowCompat.getInsetsController(act.window, view).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        onChange(true)
    }

    override fun onHideCustomView() {
        exit(notify = false)
    }

    fun exit(notify: Boolean) {
        val view = customView ?: return
        val act = activity
        (act?.window?.decorView as? FrameLayout)?.removeView(view)
        customView = null
        val callback = viewCallback
        viewCallback = null
        if (notify) callback?.onCustomViewHidden()
        if (act != null) {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            WindowCompat.getInsetsController(act.window, act.window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
        }
        onChange(false)
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
