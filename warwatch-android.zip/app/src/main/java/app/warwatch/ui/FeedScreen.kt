package app.warwatch.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.warwatch.NewsViewModel
import app.warwatch.UiState
import app.warwatch.data.NewsItem
import app.warwatch.data.Region
import app.warwatch.data.Severity
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Mono = FontFamily.Monospace

@Composable
fun FeedScreen(vm: NewsViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refresh()
                delay(60_000)
            }
        }
    }

    val visible = remember(state.items, state.region, state.query) {
        state.items.filter { item ->
            (state.region == Region.ALL || item.region == state.region) &&
                (state.query.isBlank() ||
                    item.title.contains(state.query, ignoreCase = true) ||
                    item.summary.contains(state.query, ignoreCase = true))
        }
    }
    val counts = remember(state.items) { state.items.groupingBy { it.region }.eachCount() }

    Box(Modifier.fillMaxSize().background(Cyber.Void)) {
        Column(Modifier.fillMaxSize()) {
            Header(state, onSync = vm::refresh)
            Ticker(state.items)
            SearchBox(state.query, vm::setQuery)
            RegionRow(state.region, counts, state.items.size, vm::setRegion)
            ThreatStrip(visible)

            when {
                state.loading && state.items.isEmpty() -> StatusPanel(
                    title = "ESTABLISHING UPLINK",
                    body = "Pulling reports from ${state.total} sources.",
                    color = Cyber.Cyan,
                    blink = true,
                )
                state.items.isEmpty() && state.online == 0 -> StatusPanel(
                    title = "ALL SOURCES OFFLINE",
                    body = "Check your internet connection, then tap SYNC.",
                    color = Cyber.Magenta,
                    blink = false,
                )
                visible.isEmpty() -> StatusPanel(
                    title = "NO MATCHING REPORTS",
                    body = "Clear the keyword or pick another region.",
                    color = Cyber.Amber,
                    blink = false,
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(visible, key = { it.id }) { NewsCard(it) }
                }
            }
        }
        Scanlines()
    }
}

@Composable
private fun Scanlines() {
    Canvas(Modifier.fillMaxSize()) {
        val step = 4.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = Color.Black.copy(alpha = 0.12f),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1f,
            )
            y += step
        }
    }
}

@Composable
private fun Header(state: UiState, onSync: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val alpha by pulse.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "alpha",
    )
    val synced = remember(state.lastSync) {
        if (state.lastSync == 0L) "--:--:--"
        else SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(state.lastSync))
    }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).background(Cyber.Magenta.copy(alpha = alpha), CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = "WARWATCH",
                color = Cyber.Cyan,
                fontFamily = Mono,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 22.sp,
                letterSpacing = 3.sp,
                style = TextStyle(shadow = Shadow(Cyber.Cyan, Offset.Zero, 18f)),
            )
            Text(
                text = "LINK ${state.online}/${state.total}   FEED ${state.items.size}   SYNC $synced",
                color = Cyber.Dim,
                fontFamily = Mono,
                fontSize = 11.sp,
            )
        }
        val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
        Box(
            Modifier
                .clip(shape)
                .border(1.dp, Cyber.Cyan, shape)
                .clickable(onClick = onSync)
                .padding(horizontal = 14.dp, vertical = 8.dp),
        ) {
            Text(
                text = if (state.loading) "SYNCING" else "SYNC",
                color = Cyber.Cyan,
                fontFamily = Mono,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Ticker(items: List<NewsItem>) {
    val line = remember(items) {
        items.take(10).joinToString("     //     ") { it.title }
    }
    Row(
        Modifier.fillMaxWidth().background(Cyber.Panel),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.background(Cyber.Magenta).padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text("LIVE", color = Cyber.Void, fontFamily = Mono, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
        }
        Text(
            text = line.ifBlank { "awaiting first transmission" },
            color = Cyber.Text,
            fontFamily = Mono,
            fontSize = 12.sp,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 10.dp)
                .basicMarquee(iterations = Int.MAX_VALUE, velocity = 48.dp),
        )
    }
}

@Composable
private fun SearchBox(query: String, onChange: (String) -> Unit) {
    val shape = CutCornerShape(topEnd = 10.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .border(1.dp, Cyber.Line, shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(">", color = Cyber.Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text("filter by place, group or keyword", color = Cyber.Dim, fontFamily = Mono, fontSize = 13.sp)
            }
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Cyber.Text, fontFamily = Mono, fontSize = 13.sp),
                cursorBrush = SolidColor(Cyber.Cyan),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun RegionRow(
    selected: Region,
    counts: Map<Region, Int>,
    total: Int,
    onSelect: (Region) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(Region.entries) { region ->
            val on = region == selected
            val n = if (region == Region.ALL) total else (counts[region] ?: 0)
            val shape = CutCornerShape(topEnd = 8.dp)
            Box(
                Modifier
                    .clip(shape)
                    .background(if (on) Cyber.Cyan.copy(alpha = 0.14f) else Color.Transparent)
                    .border(1.dp, if (on) Cyber.Cyan else Cyber.Line, shape)
                    .clickable { onSelect(region) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                Text(
                    text = "${region.label}  $n",
                    color = if (on) Cyber.Cyan else Cyber.Dim,
                    fontFamily = Mono,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun ThreatStrip(visible: List<NewsItem>) {
    val levels = listOf(Severity.CRITICAL, Severity.ELEVATED, Severity.DIPLOMACY)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        levels.forEach { level ->
            val color = level.color()
            val n = visible.count { it.severity == level }
            Column(
                Modifier
                    .weight(1f)
                    .background(color.copy(alpha = 0.08f))
                    .border(1.dp, color.copy(alpha = 0.45f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Text(
                    text = n.toString(),
                    color = color,
                    fontFamily = Mono,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    style = TextStyle(shadow = Shadow(color, Offset.Zero, 12f)),
                )
                Text(level.label, color = Cyber.Dim, fontFamily = Mono, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun NewsCard(item: NewsItem) {
    val context = LocalContext.current
    val color = item.severity.color()
    val shape = CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp)
    val ago = remember(item.publishedAt) { relativeTime(item.publishedAt) }

    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Cyber.Panel)
            .border(1.dp, color.copy(alpha = 0.35f), shape)
            .clickable {
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(item.link))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            .height(IntrinsicSize.Min),
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(color))
        Column(Modifier.padding(12.dp)) {
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = Cyber.Cyan, fontWeight = FontWeight.Bold)) {
                        append(item.source.uppercase())
                    }
                    withStyle(SpanStyle(color = Cyber.Dim)) { append("   $ago   ") }
                    withStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold)) {
                        append(item.severity.label)
                    }
                    withStyle(SpanStyle(color = Cyber.Dim)) { append("   ${item.region.label}") }
                },
                fontFamily = Mono,
                fontSize = 11.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = item.title,
                color = Cyber.Text,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.SemiBold,
            )
            if (item.summary.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = item.summary,
                    color = Cyber.Dim,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    maxLines = 2,
                )
            }
        }
    }
}

@Composable
private fun StatusPanel(title: String, body: String, color: Color, blink: Boolean) {
    val pulse = rememberInfiniteTransition(label = "status")
    val alpha by pulse.animateFloat(
        initialValue = if (blink) 0.35f else 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "statusAlpha",
    )
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text(
            text = title,
            color = color.copy(alpha = alpha),
            fontFamily = Mono,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 16.sp,
            letterSpacing = 2.sp,
        )
        Spacer(Modifier.height(6.dp))
        Text(body, color = Cyber.Dim, fontFamily = Mono, fontSize = 13.sp)
    }
}

private fun relativeTime(timestamp: Long): String {
    val seconds = (System.currentTimeMillis() - timestamp) / 1000
    return when {
        seconds < 60 -> "now"
        seconds < 3600 -> "${seconds / 60}m ago"
        seconds < 86_400 -> "${seconds / 3600}h ago"
        else -> "${seconds / 86_400}d ago"
    }
}
