package app.warwatch.ui

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.util.lerp as floatLerp
import androidx.core.view.WindowCompat
import app.warwatch.data.Severity

internal val Mono = FontFamily.Monospace

@Immutable
data class CyberPalette(
    val void: Color,
    val panel: Color,
    val line: Color,
    val cyan: Color,
    val magenta: Color,
    val amber: Color,
    val green: Color,
    val text: Color,
    val dim: Color,
    val glow: Float,
)

val NightPalette = CyberPalette(
    void = Color(0xFF070A12),
    panel = Color(0xFF0D1324),
    line = Color(0xFF22305A),
    cyan = Color(0xFF00E5FF),
    magenta = Color(0xFFFF2E88),
    amber = Color(0xFFFFB020),
    green = Color(0xFF39FF9C),
    text = Color(0xFFDCE8FF),
    dim = Color(0xFF8193BD),
    glow = 1f,
)

val DayPalette = CyberPalette(
    void = Color(0xFFEAF1FB),
    panel = Color(0xFFFFFFFF),
    line = Color(0xFFB7C6E2),
    cyan = Color(0xFF007C91),
    magenta = Color(0xFFD0145F),
    amber = Color(0xFFB26A00),
    green = Color(0xFF0A8F52),
    text = Color(0xFF0B1630),
    dim = Color(0xFF4F618A),
    glow = 0.25f,
)

fun lerpPalette(a: CyberPalette, b: CyberPalette, t: Float) = CyberPalette(
    void = colorLerp(a.void, b.void, t),
    panel = colorLerp(a.panel, b.panel, t),
    line = colorLerp(a.line, b.line, t),
    cyan = colorLerp(a.cyan, b.cyan, t),
    magenta = colorLerp(a.magenta, b.magenta, t),
    amber = colorLerp(a.amber, b.amber, t),
    green = colorLerp(a.green, b.green, t),
    text = colorLerp(a.text, b.text, t),
    dim = colorLerp(a.dim, b.dim, t),
    glow = floatLerp(a.glow, b.glow, t),
)

val LocalCyber = compositionLocalOf { NightPalette }

/** Read-through accessors so the rest of the UI can keep writing Cyber.Cyan, Cyber.Panel, ... */
object Cyber {
    val Void: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.void
    val Panel: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.panel
    val Line: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.line
    val Cyan: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.cyan
    val Magenta: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.magenta
    val Amber: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.amber
    val Green: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.green
    val Text: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.text
    val Dim: Color
        @Composable @ReadOnlyComposable get() = LocalCyber.current.dim
    val glow: Float
        @Composable @ReadOnlyComposable get() = LocalCyber.current.glow
}

@Composable
fun Severity.color(): Color = when (this) {
    Severity.CRITICAL -> Cyber.Magenta
    Severity.ELEVATED -> Cyber.Amber
    Severity.DIPLOMACY -> Cyber.Green
    Severity.INFO -> Cyber.Cyan
}

/** t = 0 -> night (dark cyber), t = 1 -> day (light cyber). Values in between are blended. */
@Composable
fun WarWatchTheme(t: Float, content: @Composable () -> Unit) {
    val palette = remember(t) { lerpPalette(NightPalette, DayPalette, t) }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            window.statusBarColor = palette.void.toArgb()
            window.navigationBarColor = palette.void.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = t > 0.5f
            controller.isAppearanceLightNavigationBars = t > 0.5f
        }
    }
    val scheme = if (t > 0.5f) {
        lightColorScheme(
            primary = palette.cyan,
            secondary = palette.magenta,
            background = palette.void,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text,
        )
    } else {
        darkColorScheme(
            primary = palette.cyan,
            secondary = palette.magenta,
            background = palette.void,
            surface = palette.panel,
            onBackground = palette.text,
            onSurface = palette.text,
        )
    }
    CompositionLocalProvider(LocalCyber provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
