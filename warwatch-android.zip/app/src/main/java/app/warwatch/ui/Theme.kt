package app.warwatch.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import app.warwatch.data.Severity

object Cyber {
    val Void = Color(0xFF070A12)
    val Panel = Color(0xFF0D1324)
    val Line = Color(0xFF22305A)
    val Cyan = Color(0xFF00E5FF)
    val Magenta = Color(0xFFFF2E88)
    val Amber = Color(0xFFFFB020)
    val Green = Color(0xFF39FF9C)
    val Text = Color(0xFFDCE8FF)
    val Dim = Color(0xFF8193BD)
}

fun Severity.color(): Color = when (this) {
    Severity.CRITICAL -> Cyber.Magenta
    Severity.ELEVATED -> Cyber.Amber
    Severity.DIPLOMACY -> Cyber.Green
    Severity.INFO -> Cyber.Cyan
}

@Composable
fun WarWatchTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyber.Cyan,
            secondary = Cyber.Magenta,
            background = Cyber.Void,
            surface = Cyber.Panel,
            onBackground = Cyber.Text,
            onSurface = Cyber.Text,
        ),
        content = content,
    )
}
