package app.warwatch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.warwatch.ui.FeedScreen
import app.warwatch.ui.WarWatchTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WarWatchTheme {
                FeedScreen()
            }
        }
    }
}
