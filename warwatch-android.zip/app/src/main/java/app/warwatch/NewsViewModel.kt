package app.warwatch

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.warwatch.data.NewsItem
import app.warwatch.data.NewsRepository
import app.warwatch.data.Region
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val items: List<NewsItem> = emptyList(),
    val loading: Boolean = true,
    val region: Region = Region.ALL,
    val query: String = "",
    val online: Int = 0,
    val total: Int = 0,
    val lastSync: Long = 0L,
)

class NewsViewModel : ViewModel() {
    private val repo = NewsRepository()
    private val _state = MutableStateFlow(UiState(total = repo.totalFeeds))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null

    fun refresh() {
        if (job?.isActive == true) return
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val result = runCatching { repo.load() }.getOrNull()
            _state.update { s ->
                if (result == null) {
                    s.copy(loading = false, online = 0)
                } else {
                    s.copy(
                        items = if (result.online > 0) result.items else s.items,
                        online = result.online,
                        total = result.total,
                        loading = false,
                        lastSync = System.currentTimeMillis(),
                    )
                }
            }
        }
    }

    fun setRegion(region: Region) = _state.update { it.copy(region = region) }

    fun setQuery(query: String) = _state.update { it.copy(query = query) }
}
